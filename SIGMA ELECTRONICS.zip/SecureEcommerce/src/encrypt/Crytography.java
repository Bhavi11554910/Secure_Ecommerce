package encrypt;

import org.jasypt.encryption.pbe.StandardPBEStringEncryptor;
import org.jasypt.salt.FixedStringSaltGenerator;

public class Crytography {
	public String getEncription(String data){
		String pwd = "E-Commerce";
		  
		  FixedStringSaltGenerator saltGenerator = new FixedStringSaltGenerator();                                                                                         
		  saltGenerator.setSalt("AlgoEncript");

		  StandardPBEStringEncryptor encryptor = new StandardPBEStringEncryptor();
		  encryptor.setSaltGenerator(saltGenerator);
		  encryptor.setAlgorithm("PBEWITHSHA1ANDDESEDE");
		  
		  encryptor.setPassword(pwd);
		  String encrypted= encryptor.encrypt(data);
		  return encrypted;
	}
	
	public String getDecription(String data){
		String pwd = "E-Commerce";
		  
		  FixedStringSaltGenerator saltGenerator = new FixedStringSaltGenerator();                                                                                         
		  saltGenerator.setSalt("AlgoEncript");

		  StandardPBEStringEncryptor encryptor = new StandardPBEStringEncryptor();
		  encryptor.setSaltGenerator(saltGenerator);
		  encryptor.setAlgorithm("PBEWITHSHA1ANDDESEDE");
		  
		  encryptor.setPassword(pwd);
		  String decrypted = encryptor.decrypt(data);
		  return decrypted;
	}

}
