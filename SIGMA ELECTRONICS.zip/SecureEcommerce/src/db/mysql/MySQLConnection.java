package db.mysql;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class MySQLConnection {
	private Connection conn;
	
	public MySQLConnection(){
		try{
		Class.forName("com.mysql.jdbc.Driver");
		conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/secure_ecommersedb", "root", "");
		
		//conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/sigma445_secure_ecommersedb", "sigma445_secure_ecommersedb", "PYBh6&wq$U7");
		
		}
		catch(Exception e){
			conn=null;
		}
	}
	public Connection getMySQLConnection(){
		return this.conn;
	}
	
	public void close(){
		try {
			conn.close();
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
	}
}
