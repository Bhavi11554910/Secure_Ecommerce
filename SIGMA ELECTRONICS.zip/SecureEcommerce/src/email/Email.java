package email;
import java.util.*;
import javax.mail.*;
import javax.mail.internet.*;
import javax.mail.Session;
import javax.mail.Transport;

public class Email {

	public Exception sendMail(String emailId, String subject, String messageText){
		try {
		String to=emailId;
		String body=messageText;
		final String username = "support@silverlinemarketing.in";
		final String password = "silver@123$market54";
		Properties props = new Properties();
		props.put("mail.smtp.auth", "true");
		props.put("mail.smtp.starttls.enable", "true");
		props.put("mail.smtp.host", "smtpout.secureserver.net");
		props.put("mail.smtp.port", "80");
		props.put("mail.smtp.ssl.protocols", "TLSv1.2");
		props.put("mail.smtp.ssl.ciphersuites", "TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA256");
		//props.put("mail.smtp.ssl.enable", "true");
		Session session1 = Session.getInstance(props,
		    new javax.mail.Authenticator() {
		        protected PasswordAuthentication getPasswordAuthentication() {
		            return new PasswordAuthentication(username, password);
		        }
		    });
		
		    Message message = new MimeMessage(session1);
		    message.setFrom(new InternetAddress(username));
		    message.setRecipients(Message.RecipientType.TO,
		            InternetAddress.parse(to));
		    message.setSubject(subject);
		    //message.setText(body);
		    message.setContent(body, "text/html");
		    Transport.send(message);
		    
		} catch (Exception e) {
		    
			return e;
		    
		}

		return null;

    }
	

}
